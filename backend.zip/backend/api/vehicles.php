<?php
// api/vehicles.php — REST API לרכבים
require_once __DIR__ . '/../config/auth.php';
requireLogin();

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];
$in     = readJsonBody();

switch ("$method:$action") {

  case 'GET:list':
    $p  = paginate((int)($_GET['page'] ?? 1), (int)($_GET['limit'] ?? 15));
    $s  = '%' . ($_GET['search'] ?? '') . '%';
    $allowedSort = ['id', 'plate_number', 'model', 'year', 'current_mileage'];
    $sc = in_array($_GET['sort'] ?? '', $allowedSort, true) ? $_GET['sort'] : 'id';
    $sd = ($_GET['dir'] ?? 'DESC') === 'ASC' ? 'ASC' : 'DESC';
    $custFilter = (int)($_GET['customer_id'] ?? 0);

    $where  = "(v.plate_number LIKE ? OR v.model LIKE ? OR c.full_name LIKE ?)";
    $params = [$s, $s, $s];
    if ($custFilter) { $where .= " AND v.customer_id = ?"; $params[] = $custFilter; }

    $total = Database::fetchOne(
      "SELECT COUNT(*) c FROM tbl_vehicle v
       JOIN tbl_customer c ON c.id = v.customer_id WHERE $where", $params
    )['c'];

    $rows = Database::fetchAll(
      "SELECT v.*, c.full_name AS customer_name, m.make_name,
              (SELECT COUNT(*) FROM tbl_job j WHERE j.vehicle_id = v.id) AS job_count
       FROM tbl_vehicle v
       JOIN tbl_customer c ON c.id = v.customer_id
       LEFT JOIN tbl_car_make m ON m.id = v.make_id
       WHERE $where ORDER BY v.$sc $sd LIMIT ? OFFSET ?",
      [...$params, $p['limit'], $p['offset']]
    );
    jsonOk(['rows' => $rows, 'total' => (int)$total, 'page' => $p['page']]);

  case 'GET:get':
    $r = Database::fetchOne(
      "SELECT v.*, c.full_name AS customer_name FROM tbl_vehicle v
       JOIN tbl_customer c ON c.id = v.customer_id WHERE v.id = ?",
      [(int)($_GET['id'] ?? 0)]
    );
    $r ? jsonOk($r) : jsonErr('הרכב לא נמצא', 404);

  case 'GET:options':
    jsonOk(Database::fetchAll(
      "SELECT v.id, v.plate_number, v.model, c.full_name AS customer_name
       FROM tbl_vehicle v JOIN tbl_customer c ON c.id = v.customer_id
       ORDER BY v.plate_number"
    ));

  case 'GET:makes':
    jsonOk(Database::fetchAll("SELECT id, make_name FROM tbl_car_make ORDER BY make_name"));

  case 'POST:create':
    requireRole('admin', 'receptionist');
    $plate = trim($in['plate_number'] ?? '');
    $cust  = (int)($in['customer_id'] ?? 0);
    if ($plate === '' || !$cust) jsonErr('מספר רישוי ולקוח הם שדות חובה');
    if (Database::fetchOne("SELECT id FROM tbl_vehicle WHERE plate_number = ?", [$plate]))
      jsonErr('מספר רישוי כבר קיים במערכת', 409);
    Database::query(
      "INSERT INTO tbl_vehicle (customer_id, plate_number, make_id, model, year, color, vin, engine_type, current_mileage)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
      [$cust, $plate, (int)($in['make_id'] ?? 0) ?: null, trim($in['model'] ?? ''),
       (int)($in['year'] ?? 0) ?: null, trim($in['color'] ?? ''), trim($in['vin'] ?? ''),
       $in['engine_type'] ?? 'petrol', (int)($in['current_mileage'] ?? 0)]
    );
    jsonOk(['id' => Database::lastInsertId()], 'הרכב נוסף בהצלחה');

  case 'POST:update':
    requireRole('admin', 'receptionist');
    $id    = (int)($in['id'] ?? 0);
    $plate = trim($in['plate_number'] ?? '');
    if (!$id || $plate === '') jsonErr('נתונים חסרים');
    $dup = Database::fetchOne("SELECT id FROM tbl_vehicle WHERE plate_number = ? AND id <> ?", [$plate, $id]);
    if ($dup) jsonErr('מספר רישוי כבר קיים ברכב אחר', 409);
    Database::query(
      "UPDATE tbl_vehicle SET customer_id=?, plate_number=?, make_id=?, model=?, year=?, color=?, vin=?, engine_type=?, current_mileage=? WHERE id=?",
      [(int)($in['customer_id'] ?? 0), $plate, (int)($in['make_id'] ?? 0) ?: null,
       trim($in['model'] ?? ''), (int)($in['year'] ?? 0) ?: null, trim($in['color'] ?? ''),
       trim($in['vin'] ?? ''), $in['engine_type'] ?? 'petrol', (int)($in['current_mileage'] ?? 0), $id]
    );
    jsonOk([], 'הרכב עודכן');

  case 'POST:delete':
    requireRole('admin');
    $id   = (int)($in['id'] ?? 0);
    $jobs = Database::fetchOne("SELECT COUNT(*) c FROM tbl_job WHERE vehicle_id = ?", [$id])['c'];
    if ($jobs > 0) jsonErr("לא ניתן למחוק — לרכב משויכים $jobs כרטיסי עבודה", 409);
    Database::query("DELETE FROM tbl_vehicle WHERE id = ?", [$id]);
    jsonOk([], 'הרכב נמחק');

  default:
    jsonErr('פעולה לא ידועה', 404);
}
