<?php
// api/reports.php — נתוני דוחות וסטטיסטיקות ל-Dashboard ולעמוד הדוחות
require_once __DIR__ . '/../config/auth.php';
requireLogin();

$action = $_GET['action'] ?? '';

switch ($action) {

  case 'kpis':
    // מדדי על ללוח הבקרה
    $openJobs = Database::fetchOne(
      "SELECT COUNT(*) c FROM tbl_job j JOIN tbl_job_status s ON s.id = j.status_id
       WHERE s.status_code NOT IN ('delivered','cancelled')"
    )['c'];
    $todayAppts = Database::fetchOne(
      "SELECT COUNT(*) c FROM tbl_appointment WHERE DATE(scheduled_at) = CURDATE() AND status = 'scheduled'"
    )['c'];
    $monthRevenue = Database::fetchOne(
      "SELECT COALESCE(SUM(paid_amount),0) s FROM tbl_invoice
       WHERE MONTH(issue_date) = MONTH(CURDATE()) AND YEAR(issue_date) = YEAR(CURDATE())"
    )['s'];
    $openBalance = Database::fetchOne(
      "SELECT COALESCE(SUM(total - paid_amount),0) s FROM tbl_invoice WHERE status IN ('open','partial')"
    )['s'];
    $lowStock = Database::fetchOne(
      "SELECT COUNT(*) c FROM tbl_part WHERE stock_qty <= min_stock"
    )['c'];
    $customers = Database::fetchOne("SELECT COUNT(*) c FROM tbl_customer")['c'];

    jsonOk([
      'open_jobs'     => (int)$openJobs,
      'today_appts'   => (int)$todayAppts,
      'month_revenue' => (float)$monthRevenue,
      'open_balance'  => (float)$openBalance,
      'low_stock'     => (int)$lowStock,
      'customers'     => (int)$customers,
    ]);

  case 'revenue_by_month':
    // הכנסות 6 חודשים אחרונים
    $rows = Database::fetchAll(
      "SELECT DATE_FORMAT(issue_date, '%Y-%m') ym,
              SUM(paid_amount) revenue
       FROM tbl_invoice
       WHERE issue_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
       GROUP BY ym ORDER BY ym"
    );
    jsonOk($rows);

  case 'jobs_by_status':
    $rows = Database::fetchAll(
      "SELECT s.status_name, s.color_hex, COUNT(j.id) cnt
       FROM tbl_job_status s
       LEFT JOIN tbl_job j ON j.status_id = s.id
       GROUP BY s.id ORDER BY s.id"
    );
    jsonOk($rows);

  case 'top_mechanics':
    // מכונאים מובילים לפי מספר כרטיסי עבודה
    $rows = Database::fetchAll(
      "SELECT m.full_name, COUNT(j.id) jobs, COALESCE(SUM(j.labor_hours),0) hours
       FROM tbl_mechanic m
       LEFT JOIN tbl_job j ON j.mechanic_id = m.id
       GROUP BY m.id ORDER BY jobs DESC LIMIT 5"
    );
    jsonOk($rows);

  case 'top_parts':
    // חלקים נמכרים ביותר
    $rows = Database::fetchAll(
      "SELECT p.part_name, SUM(jp.quantity) qty, SUM(jp.quantity * jp.unit_price) revenue
       FROM tbl_job_part jp JOIN tbl_part p ON p.id = jp.part_id
       GROUP BY p.id ORDER BY qty DESC LIMIT 5"
    );
    jsonOk($rows);

  default:
    jsonErr('פעולה לא ידועה', 404);
}
