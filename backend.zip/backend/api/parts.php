<?php
// api/parts.php — REST API למלאי חלקי חילוף
require_once __DIR__ . '/../config/auth.php';
requireLogin();

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];
$in     = readJsonBody();

switch ("$method:$action") {

  case 'GET:list':
    $p  = paginate((int)($_GET['page'] ?? 1), (int)($_GET['limit'] ?? 15));
    $s  = '%' . ($_GET['search'] ?? '') . '%';
    $allowedSort = ['id', 'part_number', 'part_name', 'sell_price', 'stock_qty'];
    $sc = in_array($_GET['sort'] ?? '', $allowedSort, true) ? $_GET['sort'] : 'id';
    $sd = ($_GET['dir'] ?? 'DESC') === 'ASC' ? 'ASC' : 'DESC';
    $lowOnly = ($_GET['low'] ?? '') === '1';

    $where  = "(p.part_name LIKE ? OR p.part_number LIKE ?)";
    $params = [$s, $s];
    if ($lowOnly) $where .= " AND p.stock_qty <= p.min_stock";

    $total = Database::fetchOne("SELECT COUNT(*) c FROM tbl_part p WHERE $where", $params)['c'];

    $rows = Database::fetchAll(
      "SELECT p.*, cat.category_name
       FROM tbl_part p
       LEFT JOIN tbl_part_category cat ON cat.id = p.category_id
       WHERE $where ORDER BY p.$sc $sd LIMIT ? OFFSET ?",
      [...$params, $p['limit'], $p['offset']]
    );
    jsonOk(['rows' => $rows, 'total' => (int)$total, 'page' => $p['page']]);

  case 'GET:get':
    $r = Database::fetchOne("SELECT * FROM tbl_part WHERE id = ?", [(int)($_GET['id'] ?? 0)]);
    $r ? jsonOk($r) : jsonErr('החלק לא נמצא', 404);

  case 'GET:options':
    jsonOk(Database::fetchAll(
      "SELECT id, part_number, part_name, sell_price, stock_qty FROM tbl_part ORDER BY part_name"
    ));

  case 'GET:categories':
    jsonOk(Database::fetchAll("SELECT id, category_name FROM tbl_part_category ORDER BY category_name"));

  case 'POST:create':
    requireRole('admin', 'mechanic');
    $num  = trim($in['part_number'] ?? '');
    $name = trim($in['part_name'] ?? '');
    if ($num === '' || $name === '') jsonErr('מק"ט ושם החלק הם שדות חובה');
    if (Database::fetchOne("SELECT id FROM tbl_part WHERE part_number = ?", [$num]))
      jsonErr('מק"ט כבר קיים במערכת', 409);
    Database::query(
      "INSERT INTO tbl_part (category_id, part_number, part_name, cost_price, sell_price, stock_qty, min_stock)
       VALUES (?, ?, ?, ?, ?, ?, ?)",
      [(int)($in['category_id'] ?? 0) ?: null, $num, $name,
       (float)($in['cost_price'] ?? 0), (float)($in['sell_price'] ?? 0),
       (int)($in['stock_qty'] ?? 0), (int)($in['min_stock'] ?? 2)]
    );
    jsonOk(['id' => Database::lastInsertId()], 'החלק נוסף למלאי');

  case 'POST:update':
    requireRole('admin', 'mechanic');
    $id   = (int)($in['id'] ?? 0);
    $name = trim($in['part_name'] ?? '');
    if (!$id || $name === '') jsonErr('נתונים חסרים');
    Database::query(
      "UPDATE tbl_part SET category_id=?, part_name=?, cost_price=?, sell_price=?, stock_qty=?, min_stock=? WHERE id=?",
      [(int)($in['category_id'] ?? 0) ?: null, $name, (float)($in['cost_price'] ?? 0),
       (float)($in['sell_price'] ?? 0), (int)($in['stock_qty'] ?? 0), (int)($in['min_stock'] ?? 2), $id]
    );
    jsonOk([], 'החלק עודכן');

  case 'POST:delete':
    requireRole('admin');
    $id   = (int)($in['id'] ?? 0);
    $used = Database::fetchOne("SELECT COUNT(*) c FROM tbl_job_part WHERE part_id = ?", [$id])['c'];
    if ($used > 0) jsonErr("לא ניתן למחוק — החלק מופיע ב-$used כרטיסי עבודה", 409);
    Database::query("DELETE FROM tbl_part WHERE id = ?", [$id]);
    jsonOk([], 'החלק נמחק');

  default:
    jsonErr('פעולה לא ידועה', 404);
}
