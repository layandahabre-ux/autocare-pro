<?php
// api/customers.php — REST API ללקוחות
require_once __DIR__ . '/../config/auth.php';
requireLogin();

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];
$in     = readJsonBody();

switch ("$method:$action") {

  case 'GET:list':
    $p  = paginate((int)($_GET['page'] ?? 1), (int)($_GET['limit'] ?? 15));
    $s  = '%' . ($_GET['search'] ?? '') . '%';
    $allowedSort = ['id', 'full_name', 'city', 'created_at'];
    $sc = in_array($_GET['sort'] ?? '', $allowedSort, true) ? $_GET['sort'] : 'id';
    $sd = ($_GET['dir'] ?? 'DESC') === 'ASC' ? 'ASC' : 'DESC';

    $total = Database::fetchOne(
      "SELECT COUNT(*) c FROM tbl_customer WHERE full_name LIKE ? OR phone LIKE ? OR id_number LIKE ?",
      [$s, $s, $s]
    )['c'];

    $rows = Database::fetchAll(
      "SELECT c.*,
              (SELECT COUNT(*) FROM tbl_vehicle v WHERE v.customer_id = c.id) AS vehicle_count
       FROM tbl_customer c
       WHERE c.full_name LIKE ? OR c.phone LIKE ? OR c.id_number LIKE ?
       ORDER BY $sc $sd LIMIT ? OFFSET ?",
      [$s, $s, $s, $p['limit'], $p['offset']]
    );
    jsonOk(['rows' => $rows, 'total' => (int)$total, 'page' => $p['page']]);

  case 'GET:get':
    $r = Database::fetchOne("SELECT * FROM tbl_customer WHERE id = ?", [(int)($_GET['id'] ?? 0)]);
    $r ? jsonOk($r) : jsonErr('הלקוח לא נמצא', 404);

  case 'GET:options':
    // רשימה מצומצמת לטעינת dropdown
    jsonOk(Database::fetchAll("SELECT id, full_name, phone FROM tbl_customer ORDER BY full_name"));

  case 'POST:create':
    requireRole('admin', 'receptionist');
    $name  = trim($in['full_name'] ?? '');
    $phone = trim($in['phone'] ?? '');
    if ($name === '' || $phone === '') jsonErr('שם וטלפון הם שדות חובה');
    Database::query(
      "INSERT INTO tbl_customer (full_name, id_number, phone, email, address, city, notes)
       VALUES (?, ?, ?, ?, ?, ?, ?)",
      [$name, trim($in['id_number'] ?? ''), $phone, trim($in['email'] ?? ''),
       trim($in['address'] ?? ''), trim($in['city'] ?? ''), trim($in['notes'] ?? '')]
    );
    jsonOk(['id' => Database::lastInsertId()], 'הלקוח נוסף בהצלחה');

  case 'POST:update':
    requireRole('admin', 'receptionist');
    $id   = (int)($in['id'] ?? 0);
    $name = trim($in['full_name'] ?? '');
    if (!$id || $name === '') jsonErr('נתונים חסרים');
    Database::query(
      "UPDATE tbl_customer SET full_name=?, id_number=?, phone=?, email=?, address=?, city=?, notes=? WHERE id=?",
      [$name, trim($in['id_number'] ?? ''), trim($in['phone'] ?? ''), trim($in['email'] ?? ''),
       trim($in['address'] ?? ''), trim($in['city'] ?? ''), trim($in['notes'] ?? ''), $id]
    );
    jsonOk([], 'הלקוח עודכן');

  case 'POST:delete':
    requireRole('admin');
    $id   = (int)($in['id'] ?? 0);
    $cars = Database::fetchOne("SELECT COUNT(*) c FROM tbl_vehicle WHERE customer_id = ?", [$id])['c'];
    if ($cars > 0) jsonErr("לא ניתן למחוק — ללקוח משויכים $cars רכבים", 409);
    Database::query("DELETE FROM tbl_customer WHERE id = ?", [$id]);
    jsonOk([], 'הלקוח נמחק');

  default:
    jsonErr('פעולה לא ידועה', 404);
}
