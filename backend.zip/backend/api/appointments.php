<?php
// api/appointments.php — REST API ליומן תורים
require_once __DIR__ . '/../config/auth.php';
requireLogin();

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];
$in     = readJsonBody();

switch ("$method:$action") {

  case 'GET:list':
    $p  = paginate((int)($_GET['page'] ?? 1), (int)($_GET['limit'] ?? 15));
    $s  = '%' . ($_GET['search'] ?? '') . '%';
    $allowedSort = ['id', 'scheduled_at', 'status'];
    $sc = in_array($_GET['sort'] ?? '', $allowedSort, true) ? $_GET['sort'] : 'scheduled_at';
    $sd = ($_GET['dir'] ?? 'DESC') === 'ASC' ? 'ASC' : 'DESC';

    $total = Database::fetchOne(
      "SELECT COUNT(*) c FROM tbl_appointment a
       JOIN tbl_vehicle v ON v.id = a.vehicle_id
       JOIN tbl_customer c ON c.id = v.customer_id
       WHERE v.plate_number LIKE ? OR c.full_name LIKE ? OR a.reason LIKE ?",
      [$s, $s, $s]
    )['c'];

    $rows = Database::fetchAll(
      "SELECT a.*, v.plate_number, v.model, c.full_name AS customer_name, m.full_name AS mechanic_name
       FROM tbl_appointment a
       JOIN tbl_vehicle v  ON v.id = a.vehicle_id
       JOIN tbl_customer c ON c.id = v.customer_id
       LEFT JOIN tbl_mechanic m ON m.id = a.mechanic_id
       WHERE v.plate_number LIKE ? OR c.full_name LIKE ? OR a.reason LIKE ?
       ORDER BY a.$sc $sd LIMIT ? OFFSET ?",
      [$s, $s, $s, $p['limit'], $p['offset']]
    );
    jsonOk(['rows' => $rows, 'total' => (int)$total, 'page' => $p['page']]);

  case 'GET:upcoming':
    // לרכיב הלוח בקרה: תורים קרובים
    jsonOk(Database::fetchAll(
      "SELECT a.id, a.scheduled_at, a.reason, a.status, v.plate_number, c.full_name AS customer_name
       FROM tbl_appointment a
       JOIN tbl_vehicle v ON v.id = a.vehicle_id
       JOIN tbl_customer c ON c.id = v.customer_id
       WHERE a.scheduled_at >= NOW() AND a.status = 'scheduled'
       ORDER BY a.scheduled_at ASC LIMIT 6"
    ));

  case 'GET:get':
    $r = Database::fetchOne(
      "SELECT a.*, v.plate_number, c.full_name AS customer_name
       FROM tbl_appointment a
       JOIN tbl_vehicle v ON v.id = a.vehicle_id
       JOIN tbl_customer c ON c.id = v.customer_id
       WHERE a.id = ?", [(int)($_GET['id'] ?? 0)]
    );
    $r ? jsonOk($r) : jsonErr('התור לא נמצא', 404);

  case 'POST:create':
    requireRole('admin', 'receptionist');
    $vehicle = (int)($in['vehicle_id'] ?? 0);
    $when    = trim($in['scheduled_at'] ?? '');
    if (!$vehicle || $when === '') jsonErr('יש לבחור רכב ומועד');
    Database::query(
      "INSERT INTO tbl_appointment (vehicle_id, mechanic_id, scheduled_at, duration_min, reason, status)
       VALUES (?, ?, ?, ?, ?, ?)",
      [$vehicle, (int)($in['mechanic_id'] ?? 0) ?: null, $when,
       (int)($in['duration_min'] ?? 60), trim($in['reason'] ?? ''), $in['status'] ?? 'scheduled']
    );
    jsonOk(['id' => Database::lastInsertId()], 'התור נקבע');

  case 'POST:update':
    requireRole('admin', 'receptionist');
    $id = (int)($in['id'] ?? 0);
    if (!$id) jsonErr('מזהה חסר');
    Database::query(
      "UPDATE tbl_appointment SET vehicle_id=?, mechanic_id=?, scheduled_at=?, duration_min=?, reason=?, status=? WHERE id=?",
      [(int)($in['vehicle_id'] ?? 0), (int)($in['mechanic_id'] ?? 0) ?: null,
       trim($in['scheduled_at'] ?? ''), (int)($in['duration_min'] ?? 60),
       trim($in['reason'] ?? ''), $in['status'] ?? 'scheduled', $id]
    );
    jsonOk([], 'התור עודכן');

  case 'POST:delete':
    requireRole('admin', 'receptionist');
    $id = (int)($in['id'] ?? 0);
    Database::query("DELETE FROM tbl_appointment WHERE id = ?", [$id]);
    jsonOk([], 'התור נמחק');

  default:
    jsonErr('פעולה לא ידועה', 404);
}
