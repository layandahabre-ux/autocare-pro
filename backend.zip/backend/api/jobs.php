<?php
// api/jobs.php — REST API לכרטיסי עבודה (Job Cards)
require_once __DIR__ . '/../config/auth.php';
requireLogin();

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];
$in     = readJsonBody();

switch ("$method:$action") {

  case 'GET:list':
    $p  = paginate((int)($_GET['page'] ?? 1), (int)($_GET['limit'] ?? 15));
    $s  = '%' . ($_GET['search'] ?? '') . '%';
    $allowedSort = ['id', 'job_number', 'opened_at', 'labor_hours'];
    $sc = in_array($_GET['sort'] ?? '', $allowedSort, true) ? $_GET['sort'] : 'opened_at';
    $sd = ($_GET['dir'] ?? 'DESC') === 'ASC' ? 'ASC' : 'DESC';
    $statusFilter = (int)($_GET['status_id'] ?? 0);

    $where  = "(j.job_number LIKE ? OR v.plate_number LIKE ? OR c.full_name LIKE ?)";
    $params = [$s, $s, $s];
    if ($statusFilter) { $where .= " AND j.status_id = ?"; $params[] = $statusFilter; }

    $total = Database::fetchOne(
      "SELECT COUNT(*) c FROM tbl_job j
       JOIN tbl_vehicle v ON v.id = j.vehicle_id
       JOIN tbl_customer c ON c.id = v.customer_id
       WHERE $where", $params
    )['c'];

    $rows = Database::fetchAll(
      "SELECT j.id, j.job_number, j.opened_at, j.closed_at, j.labor_hours, j.labor_rate,
              v.plate_number, v.model,
              c.full_name AS customer_name,
              m.full_name AS mechanic_name,
              st.status_name, st.color_hex,
              (j.labor_hours * j.labor_rate) AS labor_total,
              COALESCE((SELECT SUM(jp.quantity * jp.unit_price) FROM tbl_job_part jp WHERE jp.job_id = j.id), 0) AS parts_total
       FROM tbl_job j
       JOIN tbl_vehicle v  ON v.id = j.vehicle_id
       JOIN tbl_customer c ON c.id = v.customer_id
       JOIN tbl_job_status st ON st.id = j.status_id
       LEFT JOIN tbl_mechanic m ON m.id = j.mechanic_id
       WHERE $where ORDER BY j.$sc $sd LIMIT ? OFFSET ?",
      [...$params, $p['limit'], $p['offset']]
    );
    jsonOk(['rows' => $rows, 'total' => (int)$total, 'page' => $p['page']]);

  case 'GET:get':
    $id  = (int)($_GET['id'] ?? 0);
    $job = Database::fetchOne(
      "SELECT j.*, v.plate_number, v.model, c.full_name AS customer_name, c.id AS customer_id,
              m.full_name AS mechanic_name, st.status_name
       FROM tbl_job j
       JOIN tbl_vehicle v  ON v.id = j.vehicle_id
       JOIN tbl_customer c ON c.id = v.customer_id
       JOIN tbl_job_status st ON st.id = j.status_id
       LEFT JOIN tbl_mechanic m ON m.id = j.mechanic_id
       WHERE j.id = ?", [$id]
    );
    if (!$job) jsonErr('כרטיס העבודה לא נמצא', 404);
    $job['parts'] = Database::fetchAll(
      "SELECT jp.*, p.part_name, p.part_number
       FROM tbl_job_part jp JOIN tbl_part p ON p.id = jp.part_id
       WHERE jp.job_id = ?", [$id]
    );
    jsonOk($job);

  case 'GET:statuses':
    jsonOk(Database::fetchAll("SELECT id, status_code, status_name, color_hex FROM tbl_job_status ORDER BY id"));

  case 'POST:create':
    requireRole('admin', 'receptionist', 'mechanic');
    $vehicle = (int)($in['vehicle_id'] ?? 0);
    if (!$vehicle) jsonErr('יש לבחור רכב');

    $pdo = Database::getInstance();
    $pdo->beginTransaction();
    try {
      // יצירת מספר כרטיס עבודה רץ
      $year = date('Y');
      $cnt  = Database::fetchOne(
        "SELECT COUNT(*) c FROM tbl_job WHERE job_number LIKE ?", ["JOB-$year-%"]
      )['c'];
      $jobNumber = sprintf('JOB-%s-%04d', $year, $cnt + 1);

      Database::query(
        "INSERT INTO tbl_job (job_number, vehicle_id, mechanic_id, status_id, mileage_in, description, diagnosis, labor_hours, labor_rate)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        [$jobNumber, $vehicle, (int)($in['mechanic_id'] ?? 0) ?: null,
         (int)($in['status_id'] ?? 1), (int)($in['mileage_in'] ?? 0) ?: null,
         trim($in['description'] ?? ''), trim($in['diagnosis'] ?? ''),
         (float)($in['labor_hours'] ?? 0), (float)($in['labor_rate'] ?? 0)]
      );
      $jobId = Database::lastInsertId();

      // הוספת חלקים + ניכוי מהמלאי
      foreach (($in['parts'] ?? []) as $line) {
        $partId = (int)($line['part_id'] ?? 0);
        $qty    = (int)($line['quantity'] ?? 0);
        if (!$partId || $qty < 1) continue;
        $part = Database::fetchOne("SELECT sell_price, stock_qty FROM tbl_part WHERE id = ?", [$partId]);
        if (!$part) continue;
        if ($part['stock_qty'] < $qty)
          throw new Exception("מלאי לא מספיק עבור אחד החלקים (זמין: {$part['stock_qty']})");
        Database::query(
          "INSERT INTO tbl_job_part (job_id, part_id, quantity, unit_price) VALUES (?, ?, ?, ?)",
          [$jobId, $partId, $qty, $part['sell_price']]
        );
        Database::query("UPDATE tbl_part SET stock_qty = stock_qty - ? WHERE id = ?", [$qty, $partId]);
      }

      $pdo->commit();
      jsonOk(['id' => $jobId, 'job_number' => $jobNumber], 'כרטיס העבודה נפתח');
    } catch (Exception $e) {
      $pdo->rollBack();
      jsonErr($e->getMessage(), 409);
    }

  case 'POST:update':
    requireRole('admin', 'receptionist', 'mechanic');
    $id = (int)($in['id'] ?? 0);
    if (!$id) jsonErr('מזהה חסר');
    $statusId = (int)($in['status_id'] ?? 1);
    // אם הסטטוס "הושלם"/"נמסר" — נסגור תאריך
    $closed = in_array($statusId, [4, 5], true) ? date('Y-m-d H:i:s') : null;
    Database::query(
      "UPDATE tbl_job SET mechanic_id=?, status_id=?, mileage_in=?, description=?, diagnosis=?, labor_hours=?, labor_rate=?, closed_at=? WHERE id=?",
      [(int)($in['mechanic_id'] ?? 0) ?: null, $statusId, (int)($in['mileage_in'] ?? 0) ?: null,
       trim($in['description'] ?? ''), trim($in['diagnosis'] ?? ''),
       (float)($in['labor_hours'] ?? 0), (float)($in['labor_rate'] ?? 0), $closed, $id]
    );
    jsonOk([], 'כרטיס העבודה עודכן');

  case 'POST:delete':
    requireRole('admin');
    $id = (int)($in['id'] ?? 0);
    $inv = Database::fetchOne("SELECT COUNT(*) c FROM tbl_invoice WHERE job_id = ?", [$id])['c'];
    if ($inv > 0) jsonErr("לא ניתן למחוק — קיימת חשבונית המשויכת לכרטיס זה", 409);
    // החזרת חלקים למלאי לפני מחיקה
    $pdo = Database::getInstance();
    $pdo->beginTransaction();
    try {
      $parts = Database::fetchAll("SELECT part_id, quantity FROM tbl_job_part WHERE job_id = ?", [$id]);
      foreach ($parts as $pp) {
        Database::query("UPDATE tbl_part SET stock_qty = stock_qty + ? WHERE id = ?", [$pp['quantity'], $pp['part_id']]);
      }
      Database::query("DELETE FROM tbl_job WHERE id = ?", [$id]);
      $pdo->commit();
      jsonOk([], 'כרטיס העבודה נמחק והחלקים הוחזרו למלאי');
    } catch (Exception $e) {
      $pdo->rollBack();
      jsonErr('שגיאה במחיקה: ' . $e->getMessage(), 500);
    }

  default:
    jsonErr('פעולה לא ידועה', 404);
}
