<?php
// api/invoices.php — REST API לחשבוניות
require_once __DIR__ . '/../config/auth.php';
requireLogin();

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];
$in     = readJsonBody();

/** חישוב מצב תשלום לפי הסכומים */
function calcInvoiceStatus(float $total, float $paid): string
{
    if ($paid <= 0)        return 'open';
    if ($paid >= $total)   return 'paid';
    return 'partial';
}

switch ("$method:$action") {

  case 'GET:list':
    $p  = paginate((int)($_GET['page'] ?? 1), (int)($_GET['limit'] ?? 15));
    $s  = '%' . ($_GET['search'] ?? '') . '%';
    $allowedSort = ['id', 'invoice_number', 'issue_date', 'total'];
    $sc = in_array($_GET['sort'] ?? '', $allowedSort, true) ? $_GET['sort'] : 'issue_date';
    $sd = ($_GET['dir'] ?? 'DESC') === 'ASC' ? 'ASC' : 'DESC';
    $statusFilter = trim($_GET['status'] ?? '');

    $where  = "(i.invoice_number LIKE ? OR c.full_name LIKE ?)";
    $params = [$s, $s];
    if ($statusFilter !== '') { $where .= " AND i.status = ?"; $params[] = $statusFilter; }

    $total = Database::fetchOne(
      "SELECT COUNT(*) c FROM tbl_invoice i JOIN tbl_customer c ON c.id = i.customer_id WHERE $where",
      $params
    )['c'];

    $rows = Database::fetchAll(
      "SELECT i.*, c.full_name AS customer_name, j.job_number,
              (i.total - i.paid_amount) AS balance
       FROM tbl_invoice i
       JOIN tbl_customer c ON c.id = i.customer_id
       LEFT JOIN tbl_job j ON j.id = i.job_id
       WHERE $where ORDER BY i.$sc $sd LIMIT ? OFFSET ?",
      [...$params, $p['limit'], $p['offset']]
    );
    jsonOk(['rows' => $rows, 'total' => (int)$total, 'page' => $p['page']]);

  case 'GET:get':
    $id  = (int)($_GET['id'] ?? 0);
    $inv = Database::fetchOne(
      "SELECT i.*, c.full_name AS customer_name, c.phone, c.address, c.city, c.id_number,
              j.job_number
       FROM tbl_invoice i
       JOIN tbl_customer c ON c.id = i.customer_id
       LEFT JOIN tbl_job j ON j.id = i.job_id
       WHERE i.id = ?", [$id]
    );
    if (!$inv) jsonErr('החשבונית לא נמצאה', 404);
    // אם משויך כרטיס עבודה — נצרף את שורות החלקים והעבודה
    if ($inv['job_id']) {
      $inv['parts'] = Database::fetchAll(
        "SELECT p.part_name, jp.quantity, jp.unit_price, (jp.quantity * jp.unit_price) AS line_total
         FROM tbl_job_part jp JOIN tbl_part p ON p.id = jp.part_id
         WHERE jp.job_id = ?", [$inv['job_id']]
      );
      $job = Database::fetchOne("SELECT labor_hours, labor_rate FROM tbl_job WHERE id = ?", [$inv['job_id']]);
      $inv['labor_hours'] = $job['labor_hours'] ?? 0;
      $inv['labor_rate']  = $job['labor_rate'] ?? 0;
    }
    jsonOk($inv);

  case 'GET:build_from_job':
    // טעינת סכומים אוטומטית מכרטיס עבודה ליצירת חשבונית
    $jobId = (int)($_GET['job_id'] ?? 0);
    $job = Database::fetchOne(
      "SELECT j.id, j.labor_hours, j.labor_rate, v.customer_id, c.full_name AS customer_name
       FROM tbl_job j JOIN tbl_vehicle v ON v.id = j.vehicle_id
       JOIN tbl_customer c ON c.id = v.customer_id WHERE j.id = ?", [$jobId]
    );
    if (!$job) jsonErr('כרטיס עבודה לא נמצא', 404);
    $parts = Database::fetchOne(
      "SELECT COALESCE(SUM(quantity * unit_price), 0) total FROM tbl_job_part WHERE job_id = ?", [$jobId]
    )['total'];
    $labor    = (float)$job['labor_hours'] * (float)$job['labor_rate'];
    $subtotal = round($labor + (float)$parts, 2);
    jsonOk([
      'customer_id'   => $job['customer_id'],
      'customer_name' => $job['customer_name'],
      'subtotal'      => $subtotal,
      'labor_total'   => $labor,
      'parts_total'   => (float)$parts,
    ]);

  case 'POST:create':
    requireRole('admin', 'receptionist');
    $cust = (int)($in['customer_id'] ?? 0);
    if (!$cust) jsonErr('יש לבחור לקוח');

    $subtotal = (float)($in['subtotal'] ?? 0);
    $discount = (float)($in['discount'] ?? 0);
    $vatRate  = (float)($in['vat_rate'] ?? DEFAULT_VAT);
    $base     = max(0, $subtotal - $discount);
    $vat      = round($base * $vatRate / 100, 2);
    $total    = round($base + $vat, 2);
    $paid     = (float)($in['paid_amount'] ?? 0);

    $year = date('Y');
    $cnt  = Database::fetchOne("SELECT COUNT(*) c FROM tbl_invoice WHERE invoice_number LIKE ?", ["INV-$year-%"])['c'];
    $invNumber = sprintf('INV-%s-%04d', $year, $cnt + 1);

    Database::query(
      "INSERT INTO tbl_invoice (invoice_number, job_id, customer_id, issue_date, subtotal, vat_rate, vat_amount, discount, total, paid_amount, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
      [$invNumber, (int)($in['job_id'] ?? 0) ?: null, $cust,
       $in['issue_date'] ?: date('Y-m-d'), $subtotal, $vatRate, $vat, $discount, $total, $paid,
       calcInvoiceStatus($total, $paid)]
    );
    jsonOk(['id' => Database::lastInsertId(), 'invoice_number' => $invNumber], 'החשבונית נוצרה');

  case 'POST:update':
    requireRole('admin', 'receptionist');
    $id = (int)($in['id'] ?? 0);
    if (!$id) jsonErr('מזהה חסר');
    $subtotal = (float)($in['subtotal'] ?? 0);
    $discount = (float)($in['discount'] ?? 0);
    $vatRate  = (float)($in['vat_rate'] ?? DEFAULT_VAT);
    $base     = max(0, $subtotal - $discount);
    $vat      = round($base * $vatRate / 100, 2);
    $total    = round($base + $vat, 2);
    $paid     = (float)($in['paid_amount'] ?? 0);
    $status   = ($in['status'] ?? '') === 'cancelled' ? 'cancelled' : calcInvoiceStatus($total, $paid);

    Database::query(
      "UPDATE tbl_invoice SET issue_date=?, subtotal=?, vat_rate=?, vat_amount=?, discount=?, total=?, paid_amount=?, status=? WHERE id=?",
      [$in['issue_date'] ?: date('Y-m-d'), $subtotal, $vatRate, $vat, $discount, $total, $paid, $status, $id]
    );
    jsonOk([], 'החשבונית עודכנה');

  case 'POST:pay':
    requireRole('admin', 'receptionist');
    $id  = (int)($in['id'] ?? 0);
    $amt = (float)($in['amount'] ?? 0);
    $inv = Database::fetchOne("SELECT total, paid_amount FROM tbl_invoice WHERE id = ?", [$id]);
    if (!$inv) jsonErr('חשבונית לא נמצאה', 404);
    $newPaid = (float)$inv['paid_amount'] + $amt;
    Database::query(
      "UPDATE tbl_invoice SET paid_amount = ?, status = ? WHERE id = ?",
      [$newPaid, calcInvoiceStatus((float)$inv['total'], $newPaid), $id]
    );
    jsonOk(['paid' => $newPaid], 'התשלום נרשם');

  case 'POST:delete':
    requireRole('admin');
    $id = (int)($in['id'] ?? 0);
    Database::query("DELETE FROM tbl_invoice WHERE id = ?", [$id]);
    jsonOk([], 'החשבונית נמחקה');

  default:
    jsonErr('פעולה לא ידועה', 404);
}
