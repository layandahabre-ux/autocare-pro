<?php
// api/settings.php — קריאה ועדכון הגדרות מערכת
require_once __DIR__ . '/../config/auth.php';
requireLogin();

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];
$in     = readJsonBody();

switch ("$method:$action") {

  case 'GET:get':
    $s = Database::fetchOne("SELECT * FROM tbl_settings WHERE id = 1");
    $s ? jsonOk($s) : jsonErr('ההגדרות לא נמצאו', 404);

  case 'POST:update':
    requireRole('admin');
    Database::query(
      "UPDATE tbl_settings
       SET garage_name=?, garage_phone=?, garage_address=?, garage_email=?, default_vat=?, default_rate=?
       WHERE id = 1",
      [trim($in['garage_name'] ?? 'AutoCare Pro'), trim($in['garage_phone'] ?? ''),
       trim($in['garage_address'] ?? ''), trim($in['garage_email'] ?? ''),
       (float)($in['default_vat'] ?? 18), (float)($in['default_rate'] ?? 180)]
    );
    jsonOk([], 'ההגדרות נשמרו');

  default:
    jsonErr('פעולה לא ידועה', 404);
}
