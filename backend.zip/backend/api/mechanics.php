<?php
// api/mechanics.php — REST API למכונאים
require_once __DIR__ . '/../config/auth.php';
requireLogin();

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];
$in     = readJsonBody();

switch ("$method:$action") {

  case 'GET:list':
    $p  = paginate((int)($_GET['page'] ?? 1), (int)($_GET['limit'] ?? 15));
    $s  = '%' . ($_GET['search'] ?? '') . '%';
    $allowedSort = ['id', 'full_name', 'specialty', 'hourly_rate', 'hire_date'];
    $sc = in_array($_GET['sort'] ?? '', $allowedSort, true) ? $_GET['sort'] : 'id';
    $sd = ($_GET['dir'] ?? 'DESC') === 'ASC' ? 'ASC' : 'DESC';

    $total = Database::fetchOne(
      "SELECT COUNT(*) c FROM tbl_mechanic WHERE full_name LIKE ? OR specialty LIKE ?", [$s, $s]
    )['c'];

    $rows = Database::fetchAll(
      "SELECT m.*,
              (SELECT COUNT(*) FROM tbl_job j WHERE j.mechanic_id = m.id) AS job_count
       FROM tbl_mechanic m
       WHERE m.full_name LIKE ? OR m.specialty LIKE ?
       ORDER BY m.$sc $sd LIMIT ? OFFSET ?",
      [$s, $s, $p['limit'], $p['offset']]
    );
    jsonOk(['rows' => $rows, 'total' => (int)$total, 'page' => $p['page']]);

  case 'GET:get':
    $r = Database::fetchOne("SELECT * FROM tbl_mechanic WHERE id = ?", [(int)($_GET['id'] ?? 0)]);
    $r ? jsonOk($r) : jsonErr('המכונאי לא נמצא', 404);

  case 'GET:options':
    jsonOk(Database::fetchAll(
      "SELECT id, full_name, hourly_rate FROM tbl_mechanic WHERE quit_date IS NULL ORDER BY full_name"
    ));

  case 'POST:create':
    requireRole('admin');
    $name = trim($in['full_name'] ?? '');
    if ($name === '') jsonErr('שם המכונאי הוא שדה חובה');
    Database::query(
      "INSERT INTO tbl_mechanic (full_name, phone, specialty, hourly_rate, hire_date)
       VALUES (?, ?, ?, ?, ?)",
      [$name, trim($in['phone'] ?? ''), trim($in['specialty'] ?? ''),
       (float)($in['hourly_rate'] ?? 0), $in['hire_date'] ?: null]
    );
    jsonOk(['id' => Database::lastInsertId()], 'המכונאי נוסף');

  case 'POST:update':
    requireRole('admin');
    $id   = (int)($in['id'] ?? 0);
    $name = trim($in['full_name'] ?? '');
    if (!$id || $name === '') jsonErr('נתונים חסרים');
    Database::query(
      "UPDATE tbl_mechanic SET full_name=?, phone=?, specialty=?, hourly_rate=?, hire_date=?, quit_date=? WHERE id=?",
      [$name, trim($in['phone'] ?? ''), trim($in['specialty'] ?? ''),
       (float)($in['hourly_rate'] ?? 0), $in['hire_date'] ?: null, $in['quit_date'] ?: null, $id]
    );
    jsonOk([], 'המכונאי עודכן');

  case 'POST:delete':
    requireRole('admin');
    $id   = (int)($in['id'] ?? 0);
    $jobs = Database::fetchOne("SELECT COUNT(*) c FROM tbl_job WHERE mechanic_id = ?", [$id])['c'];
    if ($jobs > 0) jsonErr("לא ניתן למחוק — למכונאי משויכים $jobs כרטיסי עבודה. ניתן לסמן תאריך עזיבה במקום.", 409);
    Database::query("DELETE FROM tbl_mechanic WHERE id = ?", [$id]);
    jsonOk([], 'המכונאי נמחק');

  default:
    jsonErr('פעולה לא ידועה', 404);
}
